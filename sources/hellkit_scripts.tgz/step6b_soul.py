import bpy
bpy.ops.wm.open_mainfile(filepath='/root/hellkit/kit.blend')
soul = bpy.data.objects['soul']
# force every image on the soul down to 1024
for slot in soul.material_slots:
    if not slot.material or not slot.material.use_nodes: continue
    for n in slot.material.node_tree.nodes:
        if n.type == 'TEX_IMAGE' and n.image and max(n.image.size) > 1024:
            sc = 1024 / max(n.image.size)
            n.image.scale(int(n.image.size[0]*sc), int(n.image.size[1]*sc))
            n.image.pack()
bpy.ops.object.select_all(action='DESELECT')
soul.select_set(True)
bpy.context.view_layer.objects.active = soul
bpy.ops.export_scene.gltf(filepath='/root/hellkit/soul_raw.glb', export_format='GLB',
                          use_selection=True, export_image_format='JPEG',
                          export_jpeg_quality=78, export_yup=True, export_apply=True)
print('SOUL EXPORTED')
