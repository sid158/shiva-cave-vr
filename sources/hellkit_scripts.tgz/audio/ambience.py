import numpy as np

SR = 44100
DUR = 64.0
N = int(SR * DUR)
t = np.arange(N) / SR
rng = np.random.default_rng(66)

def lp1(x, fc):
    a = np.exp(-2*np.pi*fc/SR); y = np.empty_like(x); acc = 0.0
    b = 1 - a
    for i in range(len(x)):
        acc = a*acc + b*x[i]; y[i] = acc
    return y

# vectorised one-pole via lfilter
from scipy.signal import lfilter, butter
def lowpass(x, fc, o=2):
    b, a = butter(o, fc/(SR/2), 'low'); return lfilter(b, a, x)
def highpass(x, fc, o=2):
    b, a = butter(o, fc/(SR/2), 'high'); return lfilter(b, a, x)
def bandpass(x, lo, hi, o=2):
    b, a = butter(o, [lo/(SR/2), hi/(SR/2)], 'band'); return lfilter(b, a, x)

L = np.zeros(N); R = np.zeros(N)

# 1. sub drone — two detuned sines, slow interference beat
sub = 0.5*np.sin(2*np.pi*34.0*t) + 0.5*np.sin(2*np.pi*35.3*t + 1.0)
sub *= 0.30 * (0.75 + 0.25*np.sin(2*np.pi*t/23.0))
L += sub; R += sub

# 2. deep rumble — brown noise, heaving
w = rng.standard_normal(N)
brown = np.cumsum(w); brown /= np.abs(brown).max()
rum = lowpass(brown, 90) * (0.6 + 0.4*np.sin(2*np.pi*t/17.0 + 2))
rum = rum / (np.abs(rum).max()+1e-9) * 0.22
L += rum; R += 0.9*rum + 0.1*np.roll(rum, 997)

# 3. lava bubbling — sparse gloops, sine chirps down + filtered pop
def gloop(t0, f0, dur, amp, pan):
    n0, n1 = int(t0*SR), int((t0+dur)*SR)
    if n1 >= N: return
    tt = np.arange(n1-n0)/SR
    f = f0 * np.exp(-tt*9.0) + 45
    ph = 2*np.pi*np.cumsum(f)/SR
    env = np.exp(-tt*11.0) * np.minimum(1, tt*220)
    s = np.sin(ph) * env * amp
    L[n0:n1] += s * (1-pan); R[n0:n1] += s * pan
tt0 = 0.4
while tt0 < DUR-1:
    gloop(tt0, rng.uniform(120, 340), rng.uniform(0.18, 0.5),
          rng.uniform(0.05, 0.16), rng.uniform(0.15, 0.85))
    tt0 += rng.uniform(0.5, 2.1)

# 4. moaning wind — narrow band noise, centre gliding: a chorus in the distance
wn = rng.standard_normal(N)
for base, depth, rate, lvl, ph in [(310, 120, 1/31, 0.050, 0), (520, 200, 1/47, 0.036, 2.1),
                                    (760, 260, 1/59, 0.026, 4.0)]:
    centre = base + depth*np.sin(2*np.pi*t*rate + ph)
    # time-varying bandpass approximated in 2s blocks
    seg = int(2*SR); out = np.zeros(N)
    for s0 in range(0, N, seg):
        c = float(np.mean(centre[s0:s0+seg]))
        out[s0:s0+seg] = bandpass(wn[s0:s0+seg], max(60,c-70), c+70)
    swell = 0.5 + 0.5*np.sin(2*np.pi*t/froot) if False else (0.45 + 0.55*np.sin(2*np.pi*t*rate*1.7 + ph))
    m = out * np.maximum(0, swell) * lvl
    L += m*0.6; R += np.roll(m, 1523)*0.6

# 5. metallic groans — inharmonic ring, rare
for t0, f0 in [(9.5, 92), (26.0, 71), (41.5, 108), (55.0, 84)]:
    n0 = int(t0*SR); dur = 4.0; n1 = min(N, n0+int(dur*SR))
    tt = np.arange(n1-n0)/SR
    s = np.zeros(n1-n0)
    for mult, a in [(1, 1), (2.76, 0.5), (5.4, 0.25), (8.9, 0.12)]:
        s += a*np.sin(2*np.pi*f0*mult*tt * (1 - 0.02*tt))
    env = np.exp(-tt*1.4) * np.minimum(1, tt*30)
    s = lowpass(s*env, 1400) * 0.045
    pan = rng.uniform(0.2, 0.8)
    L[n0:n1] += s*(1-pan); R[n0:n1] += s*pan

# 6. faint hiss of hot air
hiss = highpass(rng.standard_normal(N), 2600) * 0.006 * (0.7+0.3*np.sin(2*np.pi*t/13))
L += hiss; R += np.roll(hiss, 333)

# seamless loop: circular crossfade of last 3s into first 3s
X = int(3*SR)
for ch in (L, R):
    fade = np.linspace(0, 1, X)
    head = ch[:X].copy()
    ch[:X] = head*fade + ch[-X:]*(1-fade)
mix = np.stack([L, R], 1)
mix = mix[:N-X]                      # drop the tail that was folded in
peak = np.abs(mix).max()
mix = mix/peak * 0.72
wav = (mix*32767).astype(np.int16)
import wave
with wave.open('hell_ambience.wav', 'wb') as f:
    f.setnchannels(2); f.setsampwidth(2); f.setframerate(SR)
    f.writeframes(wav.tobytes())
print('WAV done', mix.shape)
