import bpy, time

bpy.ops.wm.open_mainfile(filepath='/root/hellkit/simmed.blend')
S = bpy.context.scene
S.render.engine = 'CYCLES'
S.cycles.device = 'CPU'
S.view_layers[0].cycles.use_denoising = False

# a touch of ambient so shadow faces are not absolute zero in the bake
bpy.context.scene.world.node_tree.nodes['Background'].inputs['Color'].default_value = (0.055, 0.007, 0.005, 1)

# ---- the light rig: a camera-invisible copy of the lake, burning bright ----
# The VISIBLE lava keeps its black-crust ramp; this copy exists only to throw
# red light up onto the rock, the terraces and the souls.
_src = bpy.data.objects['lava_surface']
_lr = _src.copy(); _lr.data = _src.data.copy()
bpy.context.collection.objects.link(_lr)
_lr.name = 'light_rig'
_lr.visible_camera = False
_lm = bpy.data.materials.new('light_rig_mat')
_lm.use_nodes = True
_nt = _lm.node_tree; _nt.nodes.clear()
_out = _nt.nodes.new('ShaderNodeOutputMaterial')
_em = _nt.nodes.new('ShaderNodeEmission')
_em.inputs['Color'].default_value = (1.0, 0.26, 0.045, 1)
_em.inputs['Strength'].default_value = 9.0
_nt.links.new(_em.outputs['Emission'], _out.inputs['Surface'])
_lr.data.materials.clear()
_lr.data.materials.append(_lm)
# same trick for the far field so distant crags are not black
_fp = bpy.data.objects.get('farlava_emitter')
if _fp:
    _fl = _fp.copy(); _fl.data = _fp.data.copy()
    bpy.context.collection.objects.link(_fl)
    _fl.name = 'light_rig_far'
    _fl.visible_camera = False
    _fl.location.z = -1.7
    _fl.data.materials.clear()
    _fl.data.materials.append(_lm)


GROUPS = {
  'crags_near': (70000, 2048, 40),
  'crags_mid':  (45000, 1024, 36),
  'crags_far':  (25000, 1024, 24),
  'terraces':   (60000, 2048, 40),
  'souls':      (40000, 1024, 40),
}

def sel_only(obs):
    bpy.ops.object.select_all(action='DESELECT')
    for o in obs: o.select_set(True)
    bpy.context.view_layer.objects.active = obs[0]

def join_group(prefix):
    obs = [o for o in bpy.data.objects if o.type == 'MESH' and o.name.startswith(prefix.split('_')[0] if False else prefix)]
    return obs

# kit originals must not join into groups — remove them (parked at y=500)
for n in ('crag', 'crag_mid', 'crag_lo', 'slab', 'soul'):
    ob = bpy.data.objects.get(n)
    if ob and abs(ob.location.y - 500) < 1:
        bpy.data.objects.remove(ob, do_unlink=True)

joined = {}
for g in GROUPS:
    pref = {'crags_near':'crags_near','crags_mid':'crags_mid','crags_far':'crags_far',
            'terraces':'terr_','souls':'soul_'}[g]
    obs = [o for o in bpy.data.objects if o.type=='MESH' and o.name.startswith(pref)]
    sel_only(obs)
    if len(obs) > 1: bpy.ops.object.join()
    ob = bpy.context.view_layer.objects.active
    ob.name = g
    tgt, size, samples = GROUPS[g]
    me = ob.data; me.calc_loop_triangles()
    if len(me.loop_triangles) > tgt:
        mod = ob.modifiers.new('dec','DECIMATE'); mod.ratio = tgt/len(me.loop_triangles)
        bpy.ops.object.modifier_apply(modifier='dec')
    me.calc_loop_triangles()
    joined[g] = ob
    print('JOINED', g, len(me.loop_triangles), flush=True)

joined['lava_surface'] = bpy.data.objects['lava_surface']
GROUPS['lava_surface'] = (0, 2048, 24)

S.cycles.max_bounces = 4
S.cycles.diffuse_bounces = 3
bake_kw = dict(type='COMBINED', margin=6,
               pass_filter={'DIRECT','INDIRECT','EMIT','DIFFUSE'})

for g, ob in joined.items():
    t0 = time.time()
    _, size, samples = GROUPS[g]
    S.cycles.samples = samples
    me = ob.data
    # bake UV (target) + keep source UV for sampling
    src_uv = me.uv_layers[0].name if me.uv_layers else None
    bake_uv = me.uv_layers.new(name='bakeUV')
    me.uv_layers.active = bake_uv
    if src_uv: me.uv_layers[src_uv].active_render = True
    sel_only([ob])
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.uv.smart_project(angle_limit=1.15, island_margin=0.0018)
    bpy.ops.object.mode_set(mode='OBJECT')

    img = bpy.data.images.new(g + '_bake', size, size, alpha=False, float_buffer=False)
    for slot in ob.material_slots:
        mat = slot.material
        if not mat: continue
        if not mat.use_nodes: mat.use_nodes = True
        node = mat.node_tree.nodes.new('ShaderNodeTexImage')
        node.image = img
        mat.node_tree.nodes.active = node
    bpy.ops.object.bake(uv_layer='bakeUV', **bake_kw)
    img.filepath_raw = f'/root/hellkit/tex/{g}.png'
    img.file_format = 'PNG'
    img.save()

    # rebind: single flat material with the baked texture, only bakeUV remains
    for l in [l for l in me.uv_layers if l.name != 'bakeUV']:
        me.uv_layers.remove(l)
    mat = bpy.data.materials.new(g + '_baked')
    mat.use_nodes = True
    nt = mat.node_tree
    b = nt.nodes['Principled BSDF']
    b.inputs['Roughness'].default_value = 1.0
    t = nt.nodes.new('ShaderNodeTexImage'); t.image = img
    nt.links.new(t.outputs['Color'], b.inputs['Base Color'])
    me.materials.clear()
    me.materials.append(mat)
    print('BAKED', g, int(time.time()-t0), 's', flush=True)

# drop bake-only helpers
for ob in list(bpy.data.objects):
    if ob.name.startswith(('occ_', 'light_rig')) or ob.name == 'farlava_emitter' or ob.type == 'CAMERA':
        bpy.data.objects.remove(ob, do_unlink=True)

sel_only(list(joined.values()))
bpy.ops.export_scene.gltf(filepath='/root/hellkit/hell_env_raw.glb',
                          export_format='GLB', use_selection=True,
                          export_image_format='JPEG', export_jpeg_quality=80,
                          export_yup=True, export_apply=True)
bpy.ops.wm.save_as_mainfile(filepath='/root/hellkit/baked.blend')
print('EXPORTED', flush=True)
