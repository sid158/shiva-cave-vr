import bpy, os, sys

U = '/mnt/user-data/uploads/Downloads/'
SRC = {
  'crag': U + 'Meshy_AI_volcanic_rock_spires__0806194231_image-to-3d-texture.glb',
  'slab': U + 'Meshy_AI_volcanic_ground_slab_0806194815_image-to-3d-texture.glb',
  'soul': U + 'Meshy_AI_Emaciated_Screaming_F_0806201050_image-to-3d-texture.glb',
}

bpy.ops.wm.read_factory_settings(use_empty=True)

def import_one(name, path):
    before = set(bpy.data.objects)
    bpy.ops.import_scene.gltf(filepath=path)
    new = [o for o in set(bpy.data.objects) - before if o.type == 'MESH']
    # join if multiple meshes
    for o in bpy.data.objects: o.select_set(False)
    for o in new: o.select_set(True)
    bpy.context.view_layer.objects.active = new[0]
    if len(new) > 1: bpy.ops.object.join()
    ob = bpy.context.view_layer.objects.active
    ob.name = name
    # clear any parents/animation, apply transforms
    ob.parent = None
    ob.animation_data_clear()
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
    # kill leftover empties
    for o in [x for x in bpy.data.objects if x.type == 'EMPTY']:
        bpy.data.objects.remove(o, do_unlink=True)
    return ob

def tri_count(ob):
    m = ob.evaluated_get(bpy.context.evaluated_depsgraph_get()).to_mesh()
    n = len(m.loop_triangles) if m.loop_triangles else 0
    return n

def decimate_to(ob, target):
    bpy.context.view_layer.objects.active = ob
    m = ob.data
    m.calc_loop_triangles()
    tris = len(m.loop_triangles)
    if tris <= target: return tris
    mod = ob.modifiers.new('dec', 'DECIMATE')
    mod.ratio = target / tris
    bpy.ops.object.modifier_apply(modifier='dec')
    m.calc_loop_triangles()
    return len(m.loop_triangles)

def simplify_material(ob, maxsize=1024):
    # keep ONLY base color texture, resize to maxsize
    for slot in ob.material_slots:
        mat = slot.material
        if not mat or not mat.use_nodes: continue
        nt = mat.node_tree
        bsdf = next((n for n in nt.nodes if n.type == 'BSDF_PRINCIPLED'), None)
        base_img = None
        if bsdf:
            for lk in nt.links:
                if lk.to_node == bsdf and lk.to_socket.name == 'Base Color' and lk.from_node.type == 'TEX_IMAGE':
                    base_img = lk.from_node.image
        # rebuild minimal tree
        nt.nodes.clear()
        out = nt.nodes.new('ShaderNodeOutputMaterial')
        b = nt.nodes.new('ShaderNodeBsdfPrincipled')
        b.inputs['Roughness'].default_value = 0.95
        b.inputs['Metallic'].default_value = 0.0
        nt.links.new(b.outputs['BSDF'], out.inputs['Surface'])
        if base_img:
            if max(base_img.size) > maxsize:
                sc = maxsize / max(base_img.size)
                base_img.scale(int(base_img.size[0]*sc), int(base_img.size[1]*sc))
            t = nt.nodes.new('ShaderNodeTexImage')
            t.image = base_img
            nt.links.new(t.outputs['Color'], b.inputs['Base Color'])
    # drop all unused images
    for img in list(bpy.data.images):
        if not img.users: bpy.data.images.remove(img)

report = {}
crag = import_one('crag', SRC['crag'])
slab = import_one('slab', SRC['slab'])
soul = import_one('soul', SRC['soul'])

for ob in (crag, slab, soul):
    d = ob.dimensions
    report[ob.name + '_dims_raw'] = [round(v,2) for v in d]

# decimate: crag gets 3 LODs (duplicates), slab, soul
report['crag_hi'] = decimate_to(crag, 22000)
crag_mid = crag.copy(); crag_mid.data = crag.data.copy(); crag_mid.name='crag_mid'
bpy.context.collection.objects.link(crag_mid)
report['crag_mid'] = decimate_to(crag_mid, 8000)
crag_lo = crag.copy(); crag_lo.data = crag.data.copy(); crag_lo.name='crag_lo'
bpy.context.collection.objects.link(crag_lo)
report['crag_lo'] = decimate_to(crag_lo, 3000)
report['slab'] = decimate_to(slab, 14000)
report['soul'] = decimate_to(soul, 10000)

for ob in (crag, crag_mid, crag_lo, slab, soul):
    simplify_material(ob, 1024)

bpy.ops.wm.save_as_mainfile(filepath='/root/hellkit/kit.blend')
print('REPORT', report)
