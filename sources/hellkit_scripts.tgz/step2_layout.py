import bpy, math, random

bpy.ops.wm.open_mainfile(filepath='/root/hellkit/kit.blend')
random.seed(41)

# three.js (x,y,z) -> Blender (x, -z, y)
def BL(x, y, z): return (x, -z, y)

kit = {n: bpy.data.objects[n] for n in ('crag', 'crag_mid', 'crag_lo', 'slab', 'soul')}
# keep originals out of the scene proper
for o in kit.values():
    o.location = (0, 500, 0)

groups = {'crags_near': [], 'crags_mid': [], 'crags_far': [],
          'terraces': [], 'souls': [], 'occluders': []}

def place(src, name, pos, yaw, scale, tilt=(0,0)):
    ob = src.copy(); ob.data = src.data.copy()
    bpy.context.collection.objects.link(ob)
    ob.name = name
    ob.location = BL(*pos)
    ob.rotation_euler = (tilt[0], tilt[1], yaw)
    ob.scale = (scale[0], scale[2], scale[1])   # (x, z_three, y_three) -> BL axes
    return ob

# ============ CRAG WALLS =====================================================
# crag source is ~1.5x1.6 wide, 1.9 tall (BL z after transform_apply -> check axis)
# after gltf import + apply, the model's height is along BL Z already
def crag_ring(src, grp, count, xr, zr, hr, base_sink=1.6):
    for i in range(count):
        side = -1 if i % 2 == 0 else 1
        x = side * random.uniform(*xr)
        z = random.uniform(*zr)
        h = random.uniform(*hr)
        w = h * random.uniform(0.55, 0.85) / 1.9
        ob = place(src, f'{grp}_{i}', (x, -base_sink, z),
                   random.uniform(0, 6.28), (w, h / 1.9, w),
                   tilt=(random.uniform(-0.06, 0.06), random.uniform(-0.06, 0.06)))
        groups[grp].append(ob)

crag_ring(kit['crag'],     'crags_near', 10, (8.5, 17),  (12, -150), (5, 11))
crag_ring(kit['crag_mid'], 'crags_mid',  12, (19, 42),   (5, -175),  (11, 24))
crag_ring(kit['crag_lo'],  'crags_far',  12, (45, 78),   (-20, -205),(24, 46))
# the wall behind the gate
for i in range(5):
    x = (i - 2) * 22 + random.uniform(-5, 5)
    ob = place(kit['crag_lo'], f'crags_far_g{i}', (x, -1.6, -195 - abs(x) * 0.3),
               random.uniform(0, 6.28), (9, random.uniform(30, 48) / 1.9, 9))
    groups['crags_far'].append(ob)

# ============ TERRACES (pot mesas + banks + reference pools) =================
# pots: side*(4.0+(i%3)*0.8), z=-6-i*10.5-(i%3)*1.5  — slabs under every pot
for i in range(14):
    side = -1 if i % 2 == 0 else 1
    px = side * (4.0 + (i % 3) * 0.8)
    pz = -6 - i * 10.5 - (i % 3) * 1.5
    ob = place(kit['slab'], f'terr_pot_{i}', (px, -1.35, pz),
               random.uniform(0, 6.28), (3.4, 4.5, 3.4))
    groups['terraces'].append(ob)
# terraced pools further out — the reference's stepped basins
for i in range(10):
    side = -1 if i % 2 == 0 else 1
    x = side * random.uniform(9, 26)
    z = random.uniform(-160, 5)
    lift = random.choice([-0.6, 0.4, 1.3])
    s = random.uniform(4.5, 8.5)
    ob = place(kit['slab'], f'terr_pool_{i}', (x, -1.5 + lift, z),
               random.uniform(0, 6.28), (s, random.uniform(3, 7), s))
    groups['terraces'].append(ob)

# ============ SOULS frozen in the melt =======================================
soul_spots = [(-5.6, -1.35, -14, 0.6), (6.2, -1.5, -26, -0.8),
              (-7.0, -1.25, -47, 1.9), (5.4, -1.45, -63, 2.8),
              (-6.1, -1.3, -88, -1.4), (8.2, -1.5, -108, 0.3),
              (-4.9, -1.2, -128, 2.2), (7.4, -1.4, -142, -2.5)]
for k, (x, y, z, yaw) in enumerate(soul_spots):
    ob = place(kit['soul'], f'soul_{k}', (x, y, z), yaw,
               (1.05, 1.05, 1.05), tilt=(random.uniform(-0.25, 0.1), random.uniform(-0.2, 0.2)))
    groups['souls'].append(ob)

# ============ OCCLUDERS (baked light blockers, NOT exported) ================
def box(name, pos, dims):
    bpy.ops.mesh.primitive_cube_add(size=1, location=BL(*pos))
    ob = bpy.context.active_object
    ob.name = name
    ob.scale = (dims[0]/2, dims[2]/2, dims[1]/2)
    groups['occluders'].append(ob)
    return ob
box('occ_road', (0, -0.18, -70), (3.6, 0.35, 170))
box('occ_wall_l', (-2.0, 0.10, -70), (0.44, 0.62, 170))
box('occ_wall_r', (2.0, 0.10, -70), (0.44, 0.62, 170))
box('occ_gate', (0, 12, -166), (46, 26, 4))

# ============ LAVA: emissive far plane (bake light, not exported) ===========
bpy.ops.mesh.primitive_plane_add(size=760, location=(0, 70, -1.62))
farlava = bpy.context.active_object
farlava.name = 'farlava_emitter'

def lava_material(name, strength):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    out = nt.nodes.new('ShaderNodeOutputMaterial')
    em = nt.nodes.new('ShaderNodeEmission')
    ramp = nt.nodes.new('ShaderNodeValToRGB')
    noise = nt.nodes.new('ShaderNodeTexNoise')
    noise.inputs['Scale'].default_value = 0.05     # world-space metres
    noise.inputs['Detail'].default_value = 8.0
    noise.inputs['Roughness'].default_value = 0.62
    tc = nt.nodes.new('ShaderNodeTexCoord')
    nt.links.new(tc.outputs['Object'], noise.inputs['Vector'])
    cr = ramp.color_ramp
    cr.elements[0].position = 0.0;  cr.elements[0].color = (0.02, 0.001, 0.0005, 1)
    cr.elements[1].position = 1.0;  cr.elements[1].color = (1.0, 0.86, 0.45, 1)
    e = cr.elements.new(0.45); e.color = (0.55, 0.04, 0.004, 1)
    e = cr.elements.new(0.70); e.color = (1.0, 0.22, 0.015, 1)
    e = cr.elements.new(0.88); e.color = (1.0, 0.55, 0.08, 1)
    nt.links.new(noise.outputs['Fac'], ramp.inputs['Fac'])
    nt.links.new(ramp.outputs['Color'], em.inputs['Color'])
    em.inputs['Strength'].default_value = strength
    nt.links.new(em.outputs['Emission'], out.inputs['Surface'])
    return mat

farlava.data.materials.append(lava_material('lava_far', 7.0))

# rock material for everything solid (baked from their own textures)
# (kept as imported; crags/slabs/souls keep their meshy base color)

# ============ WORLD: near-black, blood red ==================================
w = bpy.data.worlds.new('hellworld')
bpy.context.scene.world = w
w.use_nodes = True
bg = w.node_tree.nodes['Background']
bg.inputs['Color'].default_value = (0.012, 0.001, 0.0008, 1)
bg.inputs['Strength'].default_value = 1.0

print('LAYOUT', {k: len(v) for k, v in groups.items()})
bpy.ops.wm.save_as_mainfile(filepath='/root/hellkit/scene.blend')
