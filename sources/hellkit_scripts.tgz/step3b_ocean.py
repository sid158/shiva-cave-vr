import bpy

bpy.ops.wm.open_mainfile(filepath='/root/hellkit/scene.blend')
S = bpy.context.scene

# base grid: 68 x 104 m over the core, our own topology so DISPLACE mode keeps it
bpy.ops.mesh.primitive_grid_add(x_subdivisions=150, y_subdivisions=230,
                                size=1, location=(0, 40, -0.95))
surf = bpy.context.active_object
surf.name = 'lava_surface'
surf.scale = (34, 52, 1)
bpy.ops.object.transform_apply(scale=True)

# --- fluid-spectrum simulation, tuned for a viscous melt ---------------------
oc = surf.modifiers.new('ocean', 'OCEAN')
oc.geometry_mode = 'DISPLACE'
oc.resolution = 13
oc.spatial_size = 55          # metres per tile: broad, slow forms
oc.wave_scale = 0.55          # total height budget
oc.wave_scale_min = 0.02
oc.choppiness = 2.35          # crumpled, skinned peaks — crust ridges
oc.wind_velocity = 4.0
oc.damping = 0.85             # swell dies quickly: thick fluid
oc.time = 6.4                 # a frame where the surface is rolling nicely
oc.use_normals = False

# larger swells underneath — the lake heaves
tex = bpy.data.textures.new('swell', 'CLOUDS')
tex.noise_scale = 2.6
disp = surf.modifiers.new('swell', 'DISPLACE')
disp.texture = tex
disp.texture_coords = 'GLOBAL'
disp.strength = 0.55
disp.mid_level = 0.5

bpy.ops.object.modifier_apply(modifier='ocean')
bpy.ops.object.modifier_apply(modifier='swell')

me = surf.data
me.calc_loop_triangles()
tris = len(me.loop_triangles)
if tris > 58000:
    mod = surf.modifiers.new('dec', 'DECIMATE')
    mod.ratio = 58000 / tris
    bpy.ops.object.modifier_apply(modifier='dec')
me.calc_loop_triangles()
print('SURF tris', len(me.loop_triangles))
bpy.ops.object.shade_smooth()

# hot emissive material — finer noise than the far plane, ridges read hotter
mat = bpy.data.materials['lava_far'].copy()
mat.name = 'lava_surface_mat'
nt = mat.node_tree
for n in nt.nodes:
    if n.type == 'TEX_NOISE':
        n.inputs['Scale'].default_value = 0.45
        n.inputs['Detail'].default_value = 10.0
    if n.type == 'EMISSION':
        n.inputs['Strength'].default_value = 11.0
surf.data.materials.append(mat)

# far plane must not double-light under the sim surface: cut a hole? cheaper —
# drop the far emitter slightly and let the surface occlude it
bpy.data.objects['farlava_emitter'].location.z = -1.9

bpy.ops.wm.save_as_mainfile(filepath='/root/hellkit/simmed.blend')
print('OCEAN DONE')
