import bpy

bpy.ops.wm.open_mainfile(filepath='/root/hellkit/simmed.blend')

# ---- lava material: mostly black crust, narrow white-hot veins, hot crests --
def rebuild_lava(mat, strength, noise_scale):
    nt = mat.node_tree
    nt.nodes.clear()
    out = nt.nodes.new('ShaderNodeOutputMaterial')
    em = nt.nodes.new('ShaderNodeEmission')
    em.inputs['Strength'].default_value = strength

    tc = nt.nodes.new('ShaderNodeTexCoord')
    noise = nt.nodes.new('ShaderNodeTexNoise')
    noise.inputs['Scale'].default_value = noise_scale
    noise.inputs['Detail'].default_value = 12.0
    noise.inputs['Roughness'].default_value = 0.68
    nt.links.new(tc.outputs['Object'], noise.inputs['Vector'])

    geo = nt.nodes.new('ShaderNodeNewGeometry')       # pointiness: crests run hot
    prange = nt.nodes.new('ShaderNodeMapRange')
    prange.inputs['From Min'].default_value = 0.50
    prange.inputs['From Max'].default_value = 0.62
    nt.links.new(geo.outputs['Pointiness'], prange.inputs['Value'])

    mixf = nt.nodes.new('ShaderNodeMath'); mixf.operation = 'MULTIPLY_ADD'
    nt.links.new(noise.outputs['Fac'], mixf.inputs[0])
    mixf.inputs[1].default_value = 0.72
    nt.links.new(prange.outputs['Result'], mixf.inputs[2])

    ramp = nt.nodes.new('ShaderNodeValToRGB')
    cr = ramp.color_ramp
    cr.interpolation = 'EASE'
    cr.elements[0].position = 0.0;  cr.elements[0].color = (0.006, 0.001, 0.0008, 1)
    cr.elements[1].position = 1.0;  cr.elements[1].color = (1.0, 0.88, 0.48, 1)
    for pos, col in [(0.52, (0.030, 0.003, 0.001, 1)),
                     (0.66, (0.45, 0.028, 0.002, 1)),
                     (0.78, (1.0, 0.20, 0.012, 1)),
                     (0.88, (1.0, 0.52, 0.07, 1))]:
        e = cr.elements.new(pos); e.color = col
    nt.links.new(mixf.outputs['Value'], ramp.inputs['Fac'])
    nt.links.new(ramp.outputs['Color'], em.inputs['Color'])
    nt.links.new(em.outputs['Emission'], out.inputs['Surface'])

rebuild_lava(bpy.data.materials['lava_surface_mat'], 16.0, 0.42)
rebuild_lava(bpy.data.materials['lava_far'], 10.0, 0.06)

# ---- raise the terraces out of the melt -------------------------------------
import random
random.seed(9)
for ob in bpy.data.objects:
    if ob.name.startswith('terr_pot_'):
        ob.location.z = -0.45                      # top ~ -0.06, pots sit proud
    elif ob.name.startswith('terr_pool_'):
        ob.location.z = random.choice([-0.9, -0.15, 0.75])
    elif ob.name.startswith('soul_'):
        ob.location.z = max(ob.location.z, -0.85)  # chest and arms clear the crests

bpy.ops.wm.save_as_mainfile(filepath='/root/hellkit/simmed.blend')
print('FIXED')
