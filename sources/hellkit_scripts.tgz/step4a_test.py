import bpy, math
bpy.ops.wm.open_mainfile(filepath='/root/hellkit/simmed.blend')
S = bpy.context.scene

# darken the occluder proxies so they don't bounce grey light
dark = bpy.data.materials.new('occ_dark')
dark.use_nodes = True
b = dark.node_tree.nodes['Principled BSDF']
b.inputs['Base Color'].default_value = (0.02, 0.012, 0.009, 1)
b.inputs['Roughness'].default_value = 0.95
for ob in bpy.data.objects:
    if ob.name.startswith('occ_'):
        ob.data.materials.clear()
        ob.data.materials.append(dark)

cam_data = bpy.data.cameras.new('cam')
cam = bpy.data.objects.new('cam', cam_data)
bpy.context.collection.objects.link(cam)
cam_data.angle = math.radians(80)
# stand on the causeway at three(0,1.7,-30), look toward the gate (-z => +BLy)
cam.location = (0, 30, 1.7)
cam.rotation_euler = (math.radians(87), 0, math.radians(180))
S.camera = cam

S.render.engine = 'CYCLES'
S.cycles.samples = 24
S.cycles.use_denoising = False
S.render.resolution_x = 640
S.render.resolution_y = 400
S.render.filepath = '/root/hellkit/test1.png'
S.view_settings.view_transform = 'Filmic'
S.view_settings.look = 'High Contrast'
bpy.ops.render.render(write_still=True)
print('RENDERED')
